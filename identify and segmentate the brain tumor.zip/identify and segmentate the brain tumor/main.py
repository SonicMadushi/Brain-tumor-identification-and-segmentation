from flask import Flask,render_template,request
from keras.models import Sequential,Model
from keras.layers import Dense,Activation,Flatten,Dropout
from keras.layers import Conv2D,MaxPooling2D,UpSampling2D,Input
import keras.backend as K
import numpy as np

import cv2

app=Flask(__name__)

def load_autoencoder_model():

	input_img = Input(shape=(256, 256, 1))

	x = Conv2D(32, (3, 3), activation='relu', padding='same')(input_img)
	x = MaxPooling2D((2, 2), padding='same')(x)
	x = Conv2D(32, (3, 3), activation='relu', padding='same')(x)
	encoded = MaxPooling2D((2, 2), padding='same')(x)

	x = Conv2D(32, (3, 3), activation='relu', padding='same')(encoded)
	x = UpSampling2D((2, 2))(x)
	x = Conv2D(32, (3, 3), activation='relu', padding='same')(x)
	x = UpSampling2D((2, 2))(x)
	decoded = Conv2D(1, (3, 3), activation='sigmoid', padding='same')(x)
	autoencoder = Model(input_img, decoded)
	autoencoder.load_weights('autoencorders_noise_removal.h5')
	autoencoder.compile(optimizer='adam', loss='binary_crossentropy')

	return autoencoder

def load_brain_tumor_detect_model():

	
	K.clear_session()
	model=Sequential()
	model.add(Conv2D(256,(3,3),input_shape=(50,50,1)))
	model.add(Activation('relu'))
	model.add(MaxPooling2D(pool_size=(2,2)))
    #The first CNN layer followed by Relu and MaxPooling layers
	model.add(Conv2D(128,(3,3)))
	model.add(Activation('relu'))
	model.add(MaxPooling2D(pool_size=(2,2)))
    #The second convolution layer followed by Relu and MaxPooling layers
	model.add(Flatten())
    #Flatten layer to stack the output convolutions from second convolution layer
	model.add(Dense(64,activation='relu'))
    #Dense layer of 64 neurons
	model.add(Dense(2,activation='softmax'))
    #The Final layer with two outputs for two categories
	model.compile(loss='categorical_crossentropy',optimizer='adam',metrics=['accuracy'])
    
   # model.load_weights('cat&dogs_v1.h5')
   
	model.load_weights('braintumordata_v1.h5')

	return model

@app.route('/')
def index():

	return render_template('brainTumorIdentification.html')
count=0
@app.route('/brain_tumor_detect',methods=['GET', 'POST'])
def brain_tumor_detect():
	global count
	count=count+1
	category={0:'No',1:'Yes '}

	model=load_brain_tumor_detect_model()
	autoencoder_model=load_autoencoder_model()

	file = request.files['myFile']
	file_name=file.filename
	file.save(file_name)

	imgori=cv2.imread(file_name)
	img=imgori
	gray=cv2.cvtColor(img,cv2.COLOR_BGR2GRAY)
	resized=cv2.resize(gray,(50,50))
	normalized=resized/255.0
	reshaped=np.reshape(normalized,(1,50,50,1))
	
	result=model.predict(reshaped)
	label=np.argmax(result,axis=1)[0]
	prob =np.max(result,axis=1)[0]
	prob=round(prob,2)*100


	encoder_resized = cv2.resize(gray, (256, 256))
	encoder_normalized = encoder_resized / 255.0
	encoder_reshaped = np.reshape(encoder_normalized, (1, 256, 256, 1))

	encoder_result = autoencoder_model.predict(encoder_reshaped)
	#print(encoder_result.shape,np.max(encoder_result))

	img[:50,:]=[0,255,0]
    
	cv2.putText(img,str(category[label]),(10,40),cv2.FONT_HERSHEY_SIMPLEX,1,(255,255,255),2)
	cv2.putText(img,str(prob),(200,40),cv2.FONT_HERSHEY_SIMPLEX,1,(255,255,255),2)

	cv2.imwrite('static/tumor_detect'+str(count)+'.jpg',img)
	path1="static/tumor_detect"+str(count)+".jpg"
	
	frame=imgori
	gray=cv2.cvtColor(frame,cv2.COLOR_BGR2GRAY)
	
	ret,thresh=cv2.threshold(gray,168,255,cv2.THRESH_BINARY)
	contours, hierarchy = cv2.findContours(thresh, cv2.RETR_TREE,cv2.CHAIN_APPROX_SIMPLE)
	
	#print('no. contours:',len(contours))
	
	for cnt in contours:
	#cv2.drawContours(frame, [cnt], 0, (0,255,255), 3)
		area=cv2.contourArea(cnt)
		#print(area)
		if(area>500):
			x,y,w,h = cv2.boundingRect(cnt)
			img = cv2.rectangle(frame,(x,y),(x+w,y+h),(0,255,0),2)
			cv2.drawContours(frame, [cnt], 0, (0,0,255), 1)
			cv2.imwrite('static/tumor_segment'+str(count)+'.jpg',frame)
			
	path2="static/tumor_segment"+str(count)+".jpg"
	path3='static/autoencoder' + str(count) + '.jpg'

	encoder_pixel_max=np.max(encoder_result)
	cv2.imwrite('static/autoencoder' + str(count) + '.jpg', encoder_result.reshape(256,256)*255/encoder_pixel_max)
	return render_template('brainTumorIdentification.html',path1=path1,path2=path2,path3=path3)

app.run(debug=True)
